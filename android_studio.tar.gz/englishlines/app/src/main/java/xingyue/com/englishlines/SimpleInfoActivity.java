package xingyue.com.englishlines;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import xingyue.com.englishlines.util.CommnonActivity;
import xingyue.com.englishlines.util.UpdateMe;


public class SimpleInfoActivity extends CommnonActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_info);

        TextView view = (TextView) findViewById(R.id.simple_info);
        Intent intent = getIntent();
        String message = intent.getStringExtra("last_message");
        view.setText(message);

        String opt = intent.getStringExtra("operate");
        if(opt == null) {
            opt = "DoNothing";
        }
        if(0 == opt.compareTo("update")){
            view.setText("Update download file. ");
            UpdateMe um = new UpdateMe(view,this);
            um.execute();
        }

    }
}
