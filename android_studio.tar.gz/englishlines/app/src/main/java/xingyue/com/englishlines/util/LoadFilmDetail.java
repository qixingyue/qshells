package xingyue.com.englishlines.util;

import android.os.AsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import xingyue.com.englishlines.FilmeDetail;


/**
 * Created by xingyue on 14/9/3.
 */
public class LoadFilmDetail extends AsyncTask<String,Void,String> {

    private FilmeDetail activity;

    public LoadFilmDetail(FilmeDetail activity){
        this.activity = activity;
    }

    @Override
    protected String doInBackground(String... strings) {
        String url = "http://filmlines.sinaapp.com/api/android/get_film.php?f=" + strings[0];
        String content = null;
        try {
            content = URLTool.LoadURL(url);
        } catch (IOException e) {

        }
        return content;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        try {
            JSONObject obj = new JSONObject(s);
            this.activity.setImage("http://filmlines-sound.stor.sinaapp.com/data"+obj.getString("film_img"));
            this.activity.setDescription(obj.getString("film_description"));
        } catch (JSONException e) {

        }
    }
}
