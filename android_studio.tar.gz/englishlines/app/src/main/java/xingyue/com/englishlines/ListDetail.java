package xingyue.com.englishlines;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import xingyue.com.englishlines.util.CommnonActivity;
import xingyue.com.englishlines.util.ListShow;


public class ListDetail extends CommnonActivity {

    protected String ListName;
    protected String ListID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_detail);
        final Intent intent = getIntent();
        this.ListName = intent.getStringExtra("ClickClassString");
        this.ListID = intent.getStringExtra("ClickClassID");
        setTitle(this.ListName + "Class description");
        TextView list_name = (TextView) findViewById(R.id.list_name);
        list_name.setText(this.ListName);
        ListShow ls = new ListShow((TextView)findViewById(R.id.list_description));
        ls.execute(this.ListID);
        Button btn = (Button) findViewById(R.id.press_me_to_see_list);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent.setClass(getBaseContext(),SomeMovies.class);
                startActivity(intent);
            }
        });

    }
}
