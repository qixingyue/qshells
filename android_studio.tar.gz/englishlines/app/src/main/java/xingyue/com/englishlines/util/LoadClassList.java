package xingyue.com.englishlines.util;

import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;

import xingyue.com.englishlines.MovieListActivity;
import xingyue.com.englishlines.R;

/**
 * Created by xingyue on 14/9/2.
 */
public class LoadClassList extends AsyncTask<Void,Void,HashMap> {

    private MovieListActivity activity;

    public LoadClassList(MovieListActivity movieListActivity) {
        this.activity = movieListActivity;
    }

    @Override
    protected HashMap doInBackground(Void... voids) {
        HashMap map = new HashMap();
        String url = "http://filmlines.sinaapp.com/api/android/class_list.php";
        try {
            String content = URLTool.LoadURL(url);
            JSONArray data = new JSONArray(content);
            for(int i = 0 ; i < data.length();i++){
                JSONObject obj = data.getJSONObject(i);
                map.put(obj.getString("class_name"),obj.getString("id"));
            }
        } catch (IOException e) {

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return map;
    }

    @Override
    protected void onPostExecute(HashMap data) {
        this.activity.setClassData(data);
        ListView  lv = (ListView) this.activity.findViewById(R.id.movie_class_list);
        ArrayList<String> lvdata = new ArrayList<String>();
        Object[] values = data.keySet().toArray();
        for(int i = 0 ; i< values.length;i++){
            lvdata.add((String) values[i]);
        }
        lv.setAdapter(new ArrayAdapter<String>(this.activity.getBaseContext(),android.R.layout.simple_list_item_1,lvdata));
    }
}
