package xingyue.com.englishlines.util;

import android.os.AsyncTask;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;


/**
 * Created by xingyue on 14/9/3.
 */
public class ListShow extends AsyncTask<String,Void,String> {

    private TextView description;

    public ListShow(TextView description){
        this.description = description;
    }

    @Override
    protected String doInBackground(String... lids) {
        String url = "http://filmlines.sinaapp.com/api/android/class_detail.php?c=" + lids[0];
        String content = null;
        try {
            content = URLTool.LoadURL(url);
        } catch (IOException e) {

        }
        return content;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        try {
            JSONObject obj = new JSONObject(s);
            String description = obj.getString("description");
            this.description.setText(description);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}
