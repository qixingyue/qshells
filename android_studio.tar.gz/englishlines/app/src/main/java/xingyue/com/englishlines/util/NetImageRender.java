package xingyue.com.englishlines.util;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.ImageView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by xingyue on 14/9/1.
 */
public class NetImageRender extends AsyncTask<String,Void,Bitmap> {

    private ImageView iv;

    public NetImageRender(ImageView iv){
        this.iv = iv;
    }

    @Override
    protected Bitmap doInBackground(String... strings) {
        try {
            //String url = "http://7magic.istrone.com/smartgallery/images/01/01_smaller_.jpg";
            String url = strings[0];
            InputStream in = new java.net.URL(url) .openStream();
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        if(bitmap != null) {
            iv.setImageBitmap(bitmap);
        }
    }
}
