package xingyue.com.englishlines;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.HashMap;

import xingyue.com.englishlines.util.CommnonActivity;
import xingyue.com.englishlines.util.LoadMovies;


public class SomeMovies extends CommnonActivity {
    private String list_id;

    private HashMap data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_some_movies);
        Intent intent = getIntent();
        this.list_id = intent.getStringExtra("ClickClassID");
        setTitle(intent.getStringExtra("ClickClassString") + " Movies :");
        LoadMovies lm = new LoadMovies(this);
        lm.execute(this.list_id);
        ListView lv = (ListView) findViewById(R.id.some_movies);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView tv = (TextView) view;
                String clickString = tv.getText().toString();
                String movieID = findMovieId(clickString);
                Intent intent = new Intent();
                intent.setClass(getBaseContext(),FilmeDetail.class);
                intent.putExtra("DetailID",movieID);
                intent.putExtra("DetailName",clickString);
                startActivity(intent);
            }
        });

    }

    public void setClassData(HashMap data){
        this.data = data;
    }

    private String findMovieId(String movieName){
        return (String) this.data.get(movieName);
    }
}
