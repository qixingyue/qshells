package xingyue.com.englishlines;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.util.HashMap;

import xingyue.com.englishlines.util.CommnonActivity;
import xingyue.com.englishlines.util.LoadFilmAudios;


public class AudioListActivity extends CommnonActivity {

    protected HashMap audioData = new HashMap();

    private String filmName;
    private String filmID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Intent intent = getIntent();
        this.filmID = intent.getStringExtra("DetailID");
        this.filmName = intent.getStringExtra("DetailName");
        setTitle(this.filmName + "  Audios ");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_list);
        ListView lv = (ListView) findViewById(R.id.film_audio_lv);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView tv = (TextView) view;
                String audio_text = tv.getText().toString();
                String url = findAudioURL(audio_text);
                try {
                    MediaPlayer mp = new MediaPlayer();
                    mp.setDataSource(url);
                    mp.prepare();
                    mp.start();
                } catch (IOException e) {

                }
            }
        });

        LoadFilmAudios lfa = new LoadFilmAudios(this);
        lfa.execute(this.filmID);

    }

    public void setClassData(HashMap data){
        this.audioData = data;
    }

    public String findAudioURL(String className){
        return (String) this.audioData.get(className);
    }

}
