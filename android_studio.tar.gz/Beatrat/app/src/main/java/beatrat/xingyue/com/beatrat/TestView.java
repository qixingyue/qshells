package beatrat.xingyue.com.beatrat;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

/**
 * Created by xingyue on 14/9/18.
 */
public class TestView extends View {

    private int t = 0;

    private  Canvas currentCanvas;

    public TestView(Context context) {
        super(context);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        this.currentCanvas = canvas;
        super.onDraw(canvas);
        Paint paint = new Paint();
        int red = this.getResources().getColor(R.color.red);
        paint.setColor(red);
        canvas.drawRect(new Rect(20,20,100,100),paint);
    }

    public void change() {
        this.t++;

        Paint paint = new Paint();
        int green = this.getResources().getColor(R.color.red);
        int red = this.getResources().getColor(R.color.green);
        if(0 == this.t % 2 ) {
            paint.setColor(green);
        } else {
            paint.setColor(red);
        }

        this.currentCanvas.drawRect(new Rect(20,20,100,100),paint);
    }
}
