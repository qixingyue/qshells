package xingyue.sumin.com.just4u.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.io.IOException;

import xingyue.sumin.com.just4u.R;
import xingyue.sumin.com.just4u.SimpleInfoActivity;

public class CommnonActivity extends Activity {

    protected MediaPlayer mediaPlayer = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.commnon, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        boolean deal_it = false;
        String message = "Nothing.";
        String opt = "Nothing";
        switch (id) {
            case R.id.about_me:
                deal_it = true;
                message = "Happy birthday To you . This App is only for you . Hope you like it.";
                break;
            case R.id.update_me:
                message = "Begin updating......";
                deal_it = true;
                opt = "update";
                break;
            default:

        }

        if(deal_it) {
            Intent intent = new Intent();
            intent.putExtra("last_message",message);
            intent.setClass(getBaseContext(), SimpleInfoActivity.class);
            intent.putExtra("operate",opt);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }


    /**
     * Need right of android.permission.INTERNET
     * @param url the URL OF MP3 files
     * @throws IOException
     */
    protected void playMp3(String url,boolean loop) throws IOException {
        if(this.mediaPlayer == null) {
            this.mediaPlayer = new MediaPlayer();
        }
        this.mediaPlayer.stop();
        this.mediaPlayer.setDataSource(url);
        this.mediaPlayer.setLooping(loop);
        this.mediaPlayer.prepare();
        this.mediaPlayer.start();
    }

    protected void stopMp3(){
        if(this.mediaPlayer != null) {
            this.mediaPlayer.stop();
        }
    }


    /**
     * Need right of android.permission.ACCESS_NETWORK_STATE
     *  check is wifi connected.
     * @return
     */
    protected boolean checkWifi(){
        ConnectivityManager conMan = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo.State mobile = conMan.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState();
        return mobile == NetworkInfo.State.CONNECTED ;
    }


    /**
     * Make Toast Message
     * @param message
     */
    protected void makeToastMessage(String message) {
        Toast.makeText(getBaseContext(), message, Toast.LENGTH_SHORT).show();
    }

    protected void jumpActivity(java.lang.Class<?> aim_c){
        Intent intent = new Intent();
        intent.setClass(getBaseContext(),aim_c);
        startActivity(intent);
    }

}
