package xingyue.sumin.com.just4u;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import xingyue.sumin.com.just4u.util.CommnonActivity;
import xingyue.sumin.com.just4u.util.LoadFilmDetail;
import xingyue.sumin.com.just4u.util.NetImageRender;


public class FilmeDetail extends CommnonActivity {

    private String movieID;
    private String movieName ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filme_detail);
        final Intent intent = getIntent();
        this.movieID = intent.getStringExtra("DetailID");
        this.movieName = intent.getStringExtra("DetailName");
        setTitle(this.movieName + "Detail");
        TextView movieName = (TextView) findViewById(R.id.film_detail_name);
        movieName.setText(this.movieName);

        Button button = (Button) findViewById(R.id.film_detail_more);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent.setClass(getBaseContext(),AudioListActivity.class);
                startActivity(intent);
            }
        });


        LoadFilmDetail lfd = new LoadFilmDetail(this);
        lfd.execute(this.movieID);
    }

    public void setImage(String url){
        NetImageRender nir = new NetImageRender((android.widget.ImageView) findViewById(R.id.film_detail_image));
        nir.execute(url);
    }

    public void setDescription(String description){
        TextView movieName = (TextView) findViewById(R.id.film_detail_description);
        movieName.setText(description);
    }

}
