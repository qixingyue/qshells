package xingyue.sumin.com.just4u;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import java.io.IOException;

import xingyue.sumin.com.just4u.util.CommnonActivity;


public class StartActivity extends CommnonActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        setTitle("Happy Birthday To you.");
        if(!this.checkWifi()) {
            this.makeToastMessage("Does not recommand use it non wifi.");
        }
        try {
            this.playMp3("http://filmlines-sound.stor.sinaapp.com/birthday/birthday.mp3",true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Button btn = (Button) findViewById(R.id.press_start);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    stopMp3();
                    jumpActivity(MovieListActivity.class);
            }
        });
    }

}
