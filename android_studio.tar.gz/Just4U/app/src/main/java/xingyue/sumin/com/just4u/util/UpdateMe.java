package xingyue.sumin.com.just4u.util;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.SystemClock;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

/**
 * Created by xingyue on 14/8/27.
 */
public class UpdateMe extends AsyncTask<Void,Void,String> {

    private TextView textView;
    private Activity activity;

    private String apkURL = "http://filmlines.sinaapp.com/download/happy_birthday_to_you.apk";

    public UpdateMe(TextView textView,Activity activity){
        super();
        this.textView = textView;
        this.activity = activity;
    }

    @Override
    protected String doInBackground(Void... voids) {
        String fileName = "app_update.apk";
        File file = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        file.mkdirs();
        File aim_apk = new File(file,fileName);

        String url_download = this.apkURL;

        try {
            HttpClient client = new DefaultHttpClient();
            HttpGet simple_get = new HttpGet(url_download);
            HttpResponse response = client.execute(simple_get);
            HttpEntity entity = response.getEntity();
            Long length =  entity.getContentLength();
            StringBuilder sb = new StringBuilder();
            if (null != entity) {
                InputStream is = entity.getContent();
                BufferedInputStream b_is = new BufferedInputStream(is);
                BufferedOutputStream f_out =  new BufferedOutputStream(new FileOutputStream(aim_apk));
                byte[] buffer = new byte[length.intValue()];

                int hasRead = 0;
                byte b[] = new byte[1024];
                while((hasRead = b_is.read(b)) > 0){
                    f_out.write(b, 0, hasRead);
                }

                f_out.flush();
                b_is.close();
                f_out.close();

            }
            return aim_apk.getAbsolutePath();

        } catch (Exception e) {
            return "Dowanload ERROR " + e.getMessage();
        }

    }


    @Override
    protected void onPostExecute(String result){
        this.textView.setText("Download finished.");
        File f = new File(result);
        if(f.exists()) {
            Intent intent = new Intent();
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.setAction(Intent.ACTION_VIEW);
            intent.setDataAndType(Uri.fromFile(f), "application/vnd.android.package-archive");
            this.activity.startActivity(intent);
        } else {
            this.textView.setText("I am sorry I can't find apk file. " + result);
        }
    }


}
