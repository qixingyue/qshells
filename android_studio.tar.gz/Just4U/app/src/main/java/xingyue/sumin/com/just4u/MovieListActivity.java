package xingyue.sumin.com.just4u;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.HashMap;

import xingyue.sumin.com.just4u.util.CommnonActivity;
import xingyue.sumin.com.just4u.util.LoadClassList;


public class MovieListActivity extends CommnonActivity {

    protected HashMap classData = new HashMap();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_list);
        setTitle("Movie class List");
        ListView lv = (ListView) findViewById(R.id.movie_class_list);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView tv = (TextView) view;
                String classId = findClassId(tv.getText().toString());
                Intent intent = new Intent();
                intent.setClass(getBaseContext(),ListDetail.class);
                intent.putExtra("ClickClassID",classId);
                intent.putExtra("ClickClassString",tv.getText().toString());
                startActivity(intent);
            }
        });

        LoadClassList lcl = new LoadClassList(this);
        lcl.execute();
    }

    public void setClassData(HashMap data){
           this.classData = data;
    }

    public String findClassId(String className){
          return (String) this.classData.get(className);
    }
}
