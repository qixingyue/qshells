package xingyue.sumin.com.just4u.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;

/**
 * Created by xingyue on 14/9/2.
 */
public class URLTool {

    public static String LoadURL(String url) throws IOException {
        InputStream in = new java.net.URL(url) .openStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String line;
        StringBuilder sb = new StringBuilder();
        while( null != (line = br.readLine()) ) {
            sb.append(line);
            sb.append("\n");
        }
        return sb.toString();
    }


}
