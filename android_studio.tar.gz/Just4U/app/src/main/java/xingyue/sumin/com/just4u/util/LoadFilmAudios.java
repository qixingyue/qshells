package xingyue.sumin.com.just4u.util;

import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import xingyue.sumin.com.just4u.AudioListActivity;
import xingyue.sumin.com.just4u.R;

/**
 * Created by xingyue on 14/9/3.
 */
public class LoadFilmAudios extends AsyncTask<String,Void,HashMap> {

    private AudioListActivity activity;

    public LoadFilmAudios(AudioListActivity activity){
        this.activity = activity;
    }

    @Override
    protected HashMap doInBackground(String... strings) {
        String url = "http://filmlines.sinaapp.com/api/android/get_audios.php?f="+ strings[0];
        HashMap map = new HashMap();
        try {
            String content = URLTool.LoadURL(url);
            JSONArray data = new JSONArray(content);
            for(int i = 0 ; i < data.length();i++){
                JSONObject obj = data.getJSONObject(i);
                map.put(obj.getString("audio_text"),obj.getString("audio_name"));
            }
        } catch (IOException e) {

        } catch (JSONException e) {

        }
        return map;
    }

    @Override
    protected void onPostExecute(HashMap data) {
        super.onPostExecute(data);
        this.activity.setClassData(data);
        ListView lv = (ListView) this.activity.findViewById(R.id.film_audio_lv);
        ArrayList<String> lvdata = new ArrayList<String>();
        Object[] values = data.keySet().toArray();
        for(int i = 0 ; i< values.length;i++){
            lvdata.add((String) values[i]);
        }
        lv.setAdapter(new ArrayAdapter<String>(this.activity.getBaseContext(),android.R.layout.simple_list_item_1,lvdata));

    }
}
