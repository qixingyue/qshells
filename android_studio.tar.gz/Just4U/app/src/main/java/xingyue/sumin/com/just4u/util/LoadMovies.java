package xingyue.sumin.com.just4u.util;

import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import xingyue.sumin.com.just4u.R;
import xingyue.sumin.com.just4u.SomeMovies;

/**
 * Created by xingyue on 14/9/3.
 */
public class LoadMovies extends AsyncTask<String,Void,HashMap> {

    private SomeMovies activity;

    public LoadMovies(SomeMovies sm){
        this.activity = sm;
    }

    @Override
    protected HashMap doInBackground(String... strings) {
        String url = "http://filmlines.sinaapp.com/api/android/film_list.php?c="+ strings[0];
        HashMap map = new HashMap();
        try {
            String content = URLTool.LoadURL(url);
            JSONArray data = new JSONArray(content);
            for(int i = 0 ; i < data.length();i++){
                JSONObject obj = data.getJSONObject(i);
                map.put(obj.getString("film_name"),obj.getString("id"));
            }
        } catch (IOException e) {

        } catch (JSONException e) {

        }
        return map;
    }

    @Override
    protected void onPostExecute(HashMap data) {
        super.onPostExecute(data);
        this.activity.setClassData(data);
        ListView lv = (ListView) this.activity.findViewById(R.id.some_movies);
        ArrayList<String> lvdata = new ArrayList<String>();
        Object[] values = data.keySet().toArray();
        for(int i = 0 ; i< values.length;i++){
            lvdata.add((String) values[i]);
        }
        lv.setAdapter(new ArrayAdapter<String>(this.activity.getBaseContext(),android.R.layout.simple_list_item_1,lvdata));

    }
}
