package mijoke.istrone.com.mijoke;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.Image;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Environment;
import android.os.Vibrator;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;


public class MyActivity extends Activity {

    private SensorManager sensorManager;
    private Vibrator vibrator;
    private TextView textview;
    private SoundPool sound_pool;
    private Date last_update_date;

    private SensorEventListener shake_listener = new ShakeListener(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        if(this.checkWifi()) {
            MediaPlayer mp = new MediaPlayer();

            try {
                mp.setDataSource("http://istrone.com/2012.mp3");
                mp.prepare();
                mp.start();
            } catch (IOException e) {
                textview.setText("Play Music error.");
            }
        }

        this.last_update_date = new Date(System.currentTimeMillis() - 3000 );
        this.sound_pool = new SoundPool(10, AudioManager.STREAM_SYSTEM,5);
        this.sound_pool.load(this.getBaseContext(),R.raw.shake,1);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        ImageView iv = (ImageView) findViewById(R.id.txt_img);

        if(iv == null) {
            setTitle("NULL image, What a big hole.");
        }

        NetImageRender nir = new NetImageRender(iv);
        nir.execute("http://7magic.istrone.com/smartgallery/images/01/01_smaller_.jpg");


        final TextView textView = (TextView)this.findViewById(R.id.textView);
        this.textview = textView;
        this.loadContent();
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadContent();
            }
        });
        this.sensorManager = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        this.sensorManager = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        this.vibrator = (Vibrator) this.getSystemService(VIBRATOR_SERVICE);

        if( null != this.sensorManager ) {
            this.sensorManager.registerListener(shake_listener,sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),  SensorManager.SENSOR_DELAY_NORMAL);
        }

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.my, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            this.textview.setText(R.string.about_us_settings);
            return true;
        }

        if( id == R.id.action_download ){
            this.updateMe();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPause() {
        super.onPause();
        this.sensorManager.unregisterListener(shake_listener);
        this.shake_listener = null;
    }

    @Override
    protected void onStop() {
        super.onStop();
        this.sensorManager.unregisterListener(shake_listener);
        this.shake_listener = null;
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        this.shake_listener = new ShakeListener(this);
        this.sensorManager.registerListener(shake_listener,sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),  SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onResume() {
        super.onResume();
        this.shake_listener = new ShakeListener(this);
        this.sensorManager.registerListener(shake_listener,sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),  SensorManager.SENSOR_DELAY_NORMAL);
    }

    public void loadContent(){
        Toast.makeText(getBaseContext(),"Loading....",Toast.LENGTH_SHORT).show();
        Date now_date = new Date();
        if( 1500 < ( now_date.getTime() - this.last_update_date.getTime() ) ) {
            //this.sound_pool.play(1,1, 1, 0, 0, 1);
            this.textview.setText(R.string.waiting);
            (new ConnectMe(this.textview)).execute();
            this.last_update_date = now_date;
        }
    }



    private void updateMe(){

        if(this.checkWifi()){
            this.textview.setText("Connecting infomation from server. Waiting.....");
            new UpdateMe(this.textview,this).execute();
        }

    }

    private boolean  checkWifi(){
        ConnectivityManager conMan = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo.State mobile = conMan.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState();

        if(mobile != NetworkInfo.State.CONNECTED ) {
            Toast.makeText(getBaseContext(),"Don't recommand update use GPRS",Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

}
