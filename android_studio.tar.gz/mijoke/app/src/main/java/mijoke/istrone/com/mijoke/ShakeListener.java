package mijoke.istrone.com.mijoke;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;

/**
 * Created by xingyue on 14/8/28.
 */
public class ShakeListener implements SensorEventListener {

    private MyActivity activity;

    public ShakeListener(MyActivity me){
        this.activity = me;
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        float[] values = sensorEvent.values;
        float x = values[0];
        float y = values[1];
        float z = values[2];
        float shake_value = 15;
        //textView.setText(" " + x + " " + y + " " + z + " ");
        //most of them is 19
        if( x >= shake_value || y >= shake_value || z >= shake_value) {
            this.activity.loadContent();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }


}
